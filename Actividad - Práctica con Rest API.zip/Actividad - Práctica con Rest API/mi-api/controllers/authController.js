const db = require('../config/db');
const CryptoJS = require('crypto-js');

exports.login = async (req, res) => {
  const { username, password } = req.body;
  const encryptedPassword = CryptoJS.SHA256(password).toString();

  try {
    const [user] = await db.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, encryptedPassword]);
    if (user.length > 0) {
      res.json({ message: 'Login exitoso' });
    } else {
      res.status(401).json({ message: 'Credenciales incorrectas' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
