document.addEventListener('DOMContentLoaded', () => {
    // Login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const credenciales = {
                usuario: 'A00840101',
                contraseña: 'Biologia06'
            };

            const user = document.querySelector('input[name="username"]').value;
            const pass = document.querySelector('input[name="password"]').value;
            const errorMessage = document.getElementById('error-message');

            if (user === credenciales.usuario && pass === credenciales.contraseña) {
                window.location.href = 'profile.html';
            } else {
                errorMessage.textContent = 'Credenciales incorrectas. Intenta de nuevo.';
                errorMessage.classList.remove('d-none');
                setTimeout(() => errorMessage.classList.add('d-none'), 3000);
            }
        });
    }

    // Botones interactivos
    document.querySelectorAll('.boton-interactivo').forEach(btn => {
        btn.addEventListener('click', function() {
            this.classList.toggle('btn-active');
            console.log(`Botón ${this.textContent} presionado`);
        });
    });
});