const db = require('../config/db');
const CryptoJS = require('crypto-js');

exports.login = async (req, res) => {
  const { username, password } = req.body;

  try {
    const [rows] = await db.query('SELECT * FROM users WHERE username = ?', [username]);

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Credenciales incorrectas' });
    }

    const user = rows[0];
    const salt = user.salt;
    const hashedInputPassword = CryptoJS.SHA256(password + salt).toString();

    if (hashedInputPassword === user.password_hash) {
      res.json({ message: 'Login exitoso' });
    } else {
      res.status(401).json({ message: 'Credenciales incorrectas' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
