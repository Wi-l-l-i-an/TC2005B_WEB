const crypto = require('crypto');

// Función para hashear una contraseña con salt
function hashPassword(password, salt = null) {
  if (!salt) {
    salt = crypto.randomBytes(16).toString('hex');
  }

  const hash = crypto
    .createHmac('sha256', salt)
    .update(password)
    .digest('hex');

  return { hash, salt };
}

// Verifica que una contraseña sea válida
function verifyPassword(password, salt, hashToCompare) {
  const { hash } = hashPassword(password, salt);
  return hash === hashToCompare;
}

module.exports = {
  hashPassword,
  verifyPassword
};
