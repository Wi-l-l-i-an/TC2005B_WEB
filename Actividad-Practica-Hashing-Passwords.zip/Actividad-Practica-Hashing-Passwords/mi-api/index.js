const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();{}

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// Rutas básicas
app.get('/', (req, res) => {
  res.send('Bienvenido a mi API');
});

app.get('/marco', (req, res) => {
  res.send('Polo');
});

app.get('/ping', (req, res) => {
  res.json({ message: 'pong' });
});

// Montar rutas de usuarios
const userRoutes = require('./routes/users');
const authRoutes = require('./routes/auth');

app.use('/users', userRoutes);
app.use('/login', authRoutes);

// Arrancar el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
